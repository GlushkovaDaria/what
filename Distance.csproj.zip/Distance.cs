﻿using System;

namespace DistanceTask
{
	public static class DistanceTask
	{
		// Расстояние от точки (x, y) до отрезка AB с координатами A(ax, ay), B(bx, by)
		public static double GetDistanceToSegment(double ax, double ay, double bx, double by, double x, double y)
		{
            double fromCtoA, fromCtoB, fromAtoB, d, d1, d2, angleA, angleB;

            fromCtoA = Math.Sqrt(Math.Pow(x - ax, 2) + Math.Pow(y - ay, 2));
            fromCtoB = Math.Sqrt(Math.Pow(x - bx, 2) + Math.Pow(y - by, 2));
            fromAtoB = Math.Sqrt(Math.Pow(ax - bx, 2) + Math.Pow(ay - by, 2));

            double distance1 = (x - ax) * (bx - ax) + (y - ay) * (by - ay);
            double distance2 = (x - bx) * (ax - bx) + (y - by) * (ay - by);

            double squareTriangle = Math.Abs(((x - ax) * (by - ay) - (y - ay) * (bx - ax)) / 2.0);
            double height = 2.0 * squareTriangle / fromAtoB;

            if (distance1 < 0 || distance2 < 0) return Math.Min(fromCtoA, fromCtoB);
            else if ((ax == bx) && (ay == by)) return fromCtoA;
            else return height;
        }
	}
}